# L3.0 — complete planned alternation, saved evidence

Worker status: **COMPLETED_ALL_ROUNDS**. Incomplete trajectory or missing/failed final audit; no complete-loop certification.
Closed stream-rounds: **24/24**; planned length **8** additional rounds per stream.

**Did teachers change while remaining competent?** Attempted controller outcomes and admitted experience are separate in [teacher outcomes](teacher_outcomes.csv). [Activity and fallback](acquisition_activity.csv) show every old episode reuse; a fallback-only block is inactive acquisition, even if fitting lowers its reconstruction error.

**Did learning transfer?** Final observed panels are below. Intermediate zero walking or regression did not alter the planned roster. Full survival without velocity tracking is retention, not walking.

| Stream/arm | Panel | Observed episodes | Walking | Full survival |
|---|---|---:|---:|---:|
| 0/independent | primary | 16 | 0 | 0 |
| 0/independent | confirmation | 16 | 0 | 0 |
| 0/positive | primary | 16 | 0 | 0 |
| 0/positive | confirmation | 16 | 0 | 1 |
| 1/independent | primary | 16 | 0 | 0 |
| 1/independent | confirmation | 16 | 0 | 0 |
| 1/positive | primary | 16 | 0 | 0 |
| 1/positive | confirmation | 16 | 0 | 0 |
| 2/independent | primary | 16 | 0 | 0 |
| 2/independent | confirmation | 16 | 0 | 0 |
| 2/positive | primary | 16 | 0 | 1 |
| 2/positive | confirmation | 16 | 0 | 0 |

**Did the gap contract?** See [fixed/current/held reconstruction](reconstruction.csv), [student-state queries](student_state_probes.csv), [common-anchor endpoint comparison](student_gap_endpoints.csv) and the [declared final criteria](declared_final_criteria.json). Current-teacher gap can change with the data distribution; fixed-anchor gap uses fixed states. Student queries use independent MPPI from a zero plan at the restored actual context. The observed-gap curve must be read beside reached-anchor coverage. Missing post-fall anchors are missing, not zero discrepancy. Endpoint ratios use common reached control indices and explicitly flag lost coverage. Criterion declarations need the independent audit and are not a convergence proof.

[Full standalone outcomes](standalone_outcomes.csv) · [All fitting updates](fitting_curves.csv) · [Every admission/fallback](admission_fallback.csv)

Three retained L2 minibatch streams continue different arm-specific actors/Adam states; this is not a new matched-actor initialization. Eight restart contexts share one original episode. Local teachers cover300 controls; standalone evaluations cover up to1,000. Joint-angle figures are UNPAIRED frozen slot0/first-primary illustrations, including failures, not paired performance gaps. No favorable substitution or reference-path requirement is used.

Finite contraction measurements are not proof of convergence or superiority. Equal-compute low-pass cloning/DAgger and second-body controls are absent.

Missing/unreadable evidence entries: **0**. Report rendering performs **zero physics, planner queries, neural forwards, gradients or Adam updates**. Saved accounting is preserved in the manifest; nested wall/CPU scopes must not be added twice.

Figures: [standalone_trajectory.png](standalone_trajectory.png), [teacher_trajectory.png](teacher_trajectory.png), [acquisition_activity.png](acquisition_activity.png), [fitting_trajectory.png](fitting_trajectory.png), [reconstruction_trajectory.png](reconstruction_trajectory.png), [student_state_gap_trajectory.png](student_state_gap_trajectory.png), [joint_angles_r1_s0.png](joint_angles_r1_s0.png), [joint_angles_r1_s1.png](joint_angles_r1_s1.png), [joint_angles_r1_s2.png](joint_angles_r1_s2.png), [joint_angles_r2_s0.png](joint_angles_r2_s0.png), [joint_angles_r2_s1.png](joint_angles_r2_s1.png), [joint_angles_r2_s2.png](joint_angles_r2_s2.png), [joint_angles_r3_s0.png](joint_angles_r3_s0.png), [joint_angles_r3_s1.png](joint_angles_r3_s1.png), [joint_angles_r3_s2.png](joint_angles_r3_s2.png), [joint_angles_r4_s0.png](joint_angles_r4_s0.png), [joint_angles_r4_s1.png](joint_angles_r4_s1.png), [joint_angles_r4_s2.png](joint_angles_r4_s2.png), [joint_angles_r5_s0.png](joint_angles_r5_s0.png), [joint_angles_r5_s1.png](joint_angles_r5_s1.png), [joint_angles_r5_s2.png](joint_angles_r5_s2.png), [joint_angles_r6_s0.png](joint_angles_r6_s0.png), [joint_angles_r6_s1.png](joint_angles_r6_s1.png), [joint_angles_r6_s2.png](joint_angles_r6_s2.png), [joint_angles_r7_s0.png](joint_angles_r7_s0.png), [joint_angles_r7_s1.png](joint_angles_r7_s1.png), [joint_angles_r7_s2.png](joint_angles_r7_s2.png), [joint_angles_r8_s0.png](joint_angles_r8_s0.png), [joint_angles_r8_s1.png](joint_angles_r8_s1.png), [joint_angles_r8_s2.png](joint_angles_r8_s2.png)
